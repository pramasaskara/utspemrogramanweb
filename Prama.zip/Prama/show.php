<?php
include 'config.php';

$id = $_GET['id'];
$result = $mysqli->query("SELECT * FROM players WHERE id = $id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Pemain</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Detail Pemain</h1>
        <div class="button-container">
            <a href="index.php">Kembali</a>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <td><?php echo $row['id']; ?></td>
            </tr>
            <tr>
                <th>Nama</th>
                <td><?php echo $row['nama']; ?></td>
            </tr>
            <tr>
                <th>Jabatan</th>
                <td><?php echo $row['jabatan']; ?></td>
            </tr>
            <tr>
                <th>Tahun Gabung</th>
                <td><?php echo $row['tahun_gabung']; ?></td>
            </tr>
            <tr>
                <th>Tahun Keluar</th>
                <td><?php echo $row['tahun_keluar']; ?></td>
            </tr>
            <tr>
                <th>Role</th>
                <td><?php echo $row['ROLE']; ?></td>
            </tr>
            <tr>
                <th>Hero Utama</th>
                <td><?php echo $row['hero_utama']; ?></td>
            </tr>
            <tr>
                <th>Hero Kedua</th>
                <td><?php echo $row['hero_kedua']; ?></td>
            </tr>
        </table>
    </div>
</body>
</html>
